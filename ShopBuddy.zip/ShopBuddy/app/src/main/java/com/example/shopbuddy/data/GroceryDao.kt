package com.example.shopbuddy.data

interface GroceryDao {
}