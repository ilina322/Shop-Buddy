package com.example.shopbuddy.data

class GroceryEntity {
}