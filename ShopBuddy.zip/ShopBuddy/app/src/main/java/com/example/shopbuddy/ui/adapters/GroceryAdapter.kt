package com.example.shopbuddy.ui.adapters

class GroceryAdapter {
}