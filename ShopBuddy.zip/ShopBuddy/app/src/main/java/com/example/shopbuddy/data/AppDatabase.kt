package com.example.shopbuddy.data

class AppDatabase {
}