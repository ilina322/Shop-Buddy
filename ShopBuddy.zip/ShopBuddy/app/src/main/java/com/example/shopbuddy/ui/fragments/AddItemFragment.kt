package com.example.shopbuddy.ui.fragments

class AddItemFragment {
}