package com.example.shopbuddy.utils

class Navigation {
}